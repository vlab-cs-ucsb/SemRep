#!/usr/bin/python

# -*- coding: utf-8 -*-
"""
Created on Thu Apr 10 00:51:20 2014

@author: abaki
"""

import patch_result_checker

from subprocess import Popen
from subprocess import PIPE
import os
import sys
import getopt
import re

from xlrd import open_workbook


env_setup = {"LD_LIBRARY_PATH": "/home/abaki/RA/ISSTA/SemRep/libs"}

# Folders
experimental_data_folder = os.path.abspath(os.path.join(os.getcwd(), 'experimental_data') )
excel_documents_folder = os.path.abspath(os.path.join(os.getcwd(), 'excel_documents') )
raw_result_excel_doc = os.path.abspath(os.path.join(excel_documents_folder, 'raw_results_table1_3.xlsx') )
sp_result_excel_doc = os.path.abspath(os.path.join(excel_documents_folder, 'sanitization_patch_results_table2.xlsx') )
output_folder = os.path.abspath(os.path.join(os.getcwd(), 'outputs') )

def available_options():
    print "Available Options: "
    print "-h, --help                           : lists avaiable options"
    print "-r, --reference <filename>           : reference dependency graph file path"
    print "-t, --target <filename>              : target dependency graph file path"
    print "-f, --field-name <fieldname>         : field name to analyze"
    print "-l, --language <typename>            : output language for validation and length patch(PHP, JS)"
    print "-s, --sheet-name <sheetname>  : excel sheet that you want to see the results(client_server, server_client, server_server, client_client, totals"
    print "-n --row-number <rownumber>          : row that you want to execute from the excel sheet"

reference_filepath = ""
target_filepath = ""
field_name = ""
output_language = ""

sheet_name = ""
row_number = ""
mincut_result_row = ""

try:
    opts, args = getopt.getopt(sys.argv[1:],"hr:t:f:l:s:n:",["reference=","target=", "field-name=", "language=", "sheet-name=", "row-number="])
except getopt.GetoptError:  
    available_options()
    sys.exit(2)

for opt, arg in opts:
    if opt == '-h':
        available_options()
        sys.exit()
    elif opt in ("-r", "--reference"):
        reference_filepath = arg
        default=False
    elif opt in ("-t", "--target"):
        target_filepath = arg
    elif opt in ("-f", "--field-name"):
        field_name = arg
    elif opt in ("-l", "--language"):
        output_language = arg
    elif opt in ("-s", "--sheet-name"):
        sheet_name = arg
    elif opt in ("-n", "--row-number"):
        row_number = arg



if sheet_name != "":
    if sheet_name not in ['client_server', 'server_client', 'server_server', 'client_client', 'totals']:
            available_options()
            sys.exit(2)
    wb = open_workbook(raw_result_excel_doc, "rb")
    
    row_index = int(row_number) - 1
    sheet = wb.sheet_by_name(sheet_name)
    field_name = sheet.cell(row_index, 0).value
    reference_cell = sheet.cell(row_index, 1).value
    target_cell = sheet.cell(row_index, 2).value
    
    ref_parent_folder = reference_cell[0:reference_cell.find('_')]
    tar_parent_folder = target_cell[0:target_cell.find('_')]
    
    reference_filepath = os.path.abspath(os.path.join(experimental_data_folder, ref_parent_folder, reference_cell))
    target_filepath = os.path.abspath(os.path.join(experimental_data_folder, tar_parent_folder, target_cell))
    
    mincut_result_row = field_name + "_" + reference_cell[:reference_cell.find('.')] + "_" + target_cell[:target_cell.find('.')]
    
    

cmd = ""
cmd += "./SemRep "
cmd += "--reference " + reference_filepath + " "
cmd += "--target " + target_filepath + " "
cmd += "--fieldname " + field_name + " "

print "running cmd: " + cmd 

output = Popen(cmd, shell=True, env=env_setup, stdout=PIPE).communicate()[0]
print output


def get_sp_excel_result_row_number():
    global sheet_name
    wb = open_workbook(sp_result_excel_doc, "rb")
    if sheet_name != 'totals':
        sheet = wb.sheet_by_name(sheet_name)
        for i, row in enumerate(sheet.col(0)):
            if row.value == mincut_result_row:
                return str(i+1)
        return -1
    else:
        sheet_list = ['server_client','server_server','client_client']
        for sm in sheet_list:
            sheet = wb.sheet_by_name(sm)
            for i, row in enumerate(sheet.col(0)):
                if row.value == mincut_result_row:
                    sheet_name = sm
                    return str(i+1)
    return -1
    
def get_file_path():

    r_index = reference_filepath.rfind("/") + 1
    ref_file = reference_filepath[r_index:-4]    
    
    t_index = target_filepath.rfind("/") + 1
    tar_file = target_filepath[t_index:-4]

    return ref_file + "_" + tar_file + "_" + field_name    

def write_simulation_code(code_output, output_file):
    start_index = 0
    end_index = 0
    extension = output_language.lower()
    if extension == "js":
        extension = "html"
    output_file += "." + extension
    if output_language.lower() == "php":
        start_index = code_output.find("<?php")
        end_index = code_output.rfind("?>") + 2
    elif output_language.lower() == "c":
        start_index = code_output.find("int stranger_match")
        end_index = code_output.rfind("}") + 1
    elif output_language.lower() == "js":
        start_index = code_output.find("<html>")
        end_index = code_output.rfind("</html>") + 7

    code = code_output[start_index:end_index]
    cf = open(output_file , "w")
    cf.write(code)
    cf.close()
    
    return code;
    
VP = "VLAB_VALIDATION_PATCH_BODY"
LP = "VLAB_LENGTH_PATCH_BODY"
SP = "VLAB_SANITIZATION_PATCH_BODY"
   
# default function names 
DVLPN = "stranger_match"
DSPN = "sanitize_input" 

def template_composition_code(language="js"):

    composition_code = ""
    language = language.lower()
    if language == "js":
        composition_code += "<!DOCTYPE html>\n"
        composition_code += "<html>\n"
        composition_code += " <head>\n"
        composition_code += " <title>vlab@ucsb</title>\n"
        composition_code += " <script>\n"
        composition_code += " function vlab_validation_patch(str) {\n"
        composition_code += VP
        composition_code += " }\n"
        composition_code += " function vlab_length_validation_patch(str) {\n"
        composition_code += LP
        composition_code += " }\n"        
        composition_code += " function vlab_sanitization_patch(str) {\n"
        composition_code += SP
        composition_code += " }\n"        
        composition_code += " function vlabPatch() {\n"
        composition_code += "     var x=document.getElementById(\"fname\");\n"
        composition_code += "     var r=document.getElementById(\"result\");\n"
        composition_code += "     if (!vlab_validation_patch(x.value)) {\n"
        composition_code += "         if (!vlab_length_validation_patch(x.value)) {\n"
        composition_code += "             r.style.color = \"rgb(0,255,0)\";\n"
        composition_code += "             x.style.color = \"rgb(0,255,0)\";\n"
        composition_code += "             r.innerHTML = \"&#10004; validated and sanitized\";\n"
        composition_code += "             x.value = vlab_sanitization_patch(x.value);\n"
        composition_code += "         }\n"
        composition_code += "         else {\n"
        composition_code += "             r.style.color = \"rgb(255,0,0)\";\n"
        composition_code += "             x.style.color = \"rgb(255,0,0)\";\n"
        composition_code += "             r.innerHTML = \"&#10008; (length patch)\";\n"                 
        composition_code += "         }\n"
        composition_code += "     }\n"
        composition_code += "     else {\n"
        composition_code += "         r.style.color = \"rgb(255,0,0)\";\n"
        composition_code += "         x.style.color = \"rgb(255,0,0)\";\n"
        composition_code += "         r.innerHTML = \"&#10008; (validation patch)\";\n"                 
        composition_code += "     }\n"
        composition_code += " }\n"
        composition_code += " window.onload = vlabPatch;\n"
        composition_code += " </script>\n"
        composition_code += " </head>\n"
        composition_code += " <body>\n"
        composition_code += "Enter your string: <input type=\"text\" id=\"fname\" onkeyup=\"vlabPatch()\">&nbsp; <span id=\"result\" style=\"color:red\"></span>\n"
        composition_code += "<p>When you input a character, a function is triggered which validates and sanitizes the input string.</p>\n"
        composition_code += "</body>\n"
        composition_code += "</html>\n"
    else: #php
        composition_code = "<?php\n"
        composition_code += " function vlab_validation_patch($str) {\n"
        composition_code += VP
        composition_code += " }\n"
        composition_code += " function vlab_length_validation_patch($str) {\n"
        composition_code += LP
        composition_code += " }\n"        
        composition_code += " function vlab_sanitization_patch($str) {\n"
        composition_code += SP
        composition_code += " }\n"        
        composition_code += " function vlabPatch($str) {\n"
        composition_code += "     if (!vlab_validation_patch($str)) {\n"
        composition_code += "         if (!vlab_length_validation_patch($str)) {\n"
        composition_code += "             echo \"validated and sanitized string: <b>\" . vlab_sanitization_patch($str) . \"</b>\";\n"
        composition_code += "         }\n"
        composition_code += "         else {\n"
        composition_code += "           echo \"not valid (length patch)\";\n"                
        composition_code += "         }\n"
        composition_code += "     }\n"
        composition_code += "     else {\n"
        composition_code += "         echo \"not valid (validation patch)\";\n"               
        composition_code += "     }\n"
        composition_code += " }\n"
        composition_code += " if (isset($_REQUEST['str'])) {\n"
        composition_code += "   vlabPatch($_REQUEST['str']);\n"
        composition_code += " }\n"
        composition_code += " else {\n"
        composition_code += "   echo \"Please send a POST or GET request with by using 'str' parameter!\";\n"               
        composition_code += " }\n"
        composition_code += "?>\n"
        
    return composition_code
    
def replace_template_function_body(template, subject, replacement_code, function_name, default_body ):

    body = replacement_code[replacement_code.find("{", replacement_code.find(function_name)) + 1:]
    
    body = body[:body.find("}", body.find("return"))]
    
    return template.replace(subject,body)

template_ouput_code = template_composition_code(output_language)
    
output_file_path = os.path.abspath(os.path.join(output_folder, get_file_path()))    

row_data_file = output_file_path + '_result_row.csv'

patch_result_checker.extract_results(output, row_data_file)

vpr = patch_result_checker.shared_results.is_validation_patch_required
lpr = patch_result_checker.shared_results.is_length_patch_required
spr = patch_result_checker.shared_results.is_sanitization_patch_required

if vpr == "yes":
    print "...Generating code for validation patch: " 
    cmd = ""
    cmd += "java -jar mincut_codegen.jar "
    cmd += "-p " + patch_result_checker.shared_results.vp_filename + " "
    cmd += "-s "
    cmd += "-l " + output_language + " "
    print "running command: " + cmd
    output = Popen(cmd, shell=True ,stdout=PIPE).communicate()[0]
    code_output_file = output_file_path + "_vp_simulation_code"
    code_ouput = write_simulation_code(output, code_output_file)
    print "\nValidation Patch simulation code written: " + code_output_file + "\n"
    template_ouput_code = replace_template_function_body(template_ouput_code, VP, code_ouput, DVLPN, "      return false;\n")
else:
    print "...... no validation patch required"
    template_ouput_code = replace_template_function_body(template_ouput_code, VP, "", DVLPN, "      return false;\n")
    

if lpr == "yes":
    print "...Generating code for length patch: "
    cmd = ""    
    cmd += "java -jar mincut_codegen.jar "
    cmd += "-p " + patch_result_checker.shared_results.lp_filename + " "
    cmd += "-s "
    cmd += "-l " + output_language + " "
    print "running command: " + cmd
    output = Popen(cmd, shell=True ,stdout=PIPE).communicate()[0]
    code_output_file = output_file_path + "_lp_simulation_code"
    code_ouput = write_simulation_code(output, code_output_file)
    print "\nLength Patch simulation code written: " + code_output_file + "\n"
    
    template_ouput_code = replace_template_function_body(template_ouput_code, LP, code_ouput, DVLPN, "      return false;\n")
else:
    print "...... no length patch required"
    template_ouput_code = replace_template_function_body(template_ouput_code, LP, "", DVLPN, "      return false;\n")

default_body = "      return str;\n"
if output_language.lower() == "php" :
    default_body = "     return $str;\n"    
if spr == "yes":
    print "...Running mincut algorithm to make sanitization repair suggestions"
    cmd = ""
    cmd += "java -jar mincut_codegen.jar "
    cmd += "-p " + patch_result_checker.shared_results.sp_filename + " "
    cmd += "-r " + patch_result_checker.shared_results.refsink_filename + " "
    cmd += "-l " + output_language + " "
    print "running command: " + cmd
    output = Popen(cmd, shell=True ,stdout=PIPE).communicate()[0]
    mincut_summary = output[output.find("...mincut"):]
    code_output_file = output_file_path + "_sp_simulation_code"
    code_ouput = write_simulation_code(mincut_summary, code_output_file)
    print "\nSanitization Patch simulation code written: " + code_output_file
    template_ouput_code = replace_template_function_body(template_ouput_code, SP, code_ouput, DSPN, default_body)

    mincut_summary_file = output_file_path + "_sp.mincut_summary"
    cf = open(mincut_summary_file , "w")
    cf.write(mincut_summary)
    cf.close()

    print "Mincut Results are written : " + mincut_summary_file + "\n"
    if (sheet_name != ""):  
        sp_row = get_sp_excel_result_row_number()  
else:
    print "...... no sanitization patch required"
    template_ouput_code = replace_template_function_body(template_ouput_code, SP, "", DSPN, default_body)
 
if vpr == "yes" or lpr == "yes" or spr == "yes":
    extension = output_language.lower()
    if extension == "js":
        extension = "html"
    composition_output_file = output_file_path + "_composed_patches." + extension
    cf = open(composition_output_file, "w")
    cf.write(template_ouput_code)
    cf.close()
    
    
print "\n\n---------- EXECUTION SUMMARY ------------------------------------"
print "--->  validation patch: " + vpr + ", length patch: " + lpr + ", sanitization patch: " + spr
print "\n--->  raw results excel row for this execution (Table 1, Table 3) (performance related data may differ): \n"+ patch_result_checker.shared_results.__str__()
if  sheet_name != "":
    if spr == "yes":
        print "\n--->  raw sanitization patch result (mincut) excel details (Table 2): file: sanitization_patch_results_table2.xlsx, sheet name: " + sheet_name + ", row number: " + str(sp_row )
    else:
        print "\n--->  do not have sanitization patch details (mincut)"
print "\n--->  you can check the outputs folder for the generated output files: " + output_file_path + "*"   
print "\n\n"

